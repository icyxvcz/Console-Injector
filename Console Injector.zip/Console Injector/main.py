# enjoy and have fun skidding

import json
import re
import requests
import os
import sys
import time
from collections import OrderedDict
from typing import Dict, Optional, Tuple
from core.memory import memoryman, closehandle

offsetsbaseurl = "https://offsets.imtheo.lol"
robloxversionendpoint = "https://clientsettingscdn.roblox.com/v2/client-version/WindowsPlayer"

# last known good version + offset, used ONLY when explicitly requested (env var)
# these are tied to one specific Roblox build and are NOT safe as automatic fallbacks
defaultversionhash = "c5aecda2245e4fae"
defaultmagicoffset = 0x887ca40

# set ICY_ALLOW_STALE_OFFSETS=1 to permit falling back to the hardcoded offset
# when the live version can't be detected or theo has no dump for it
allowstaleenv = "ICY_ALLOW_STALE_OFFSETS"

# how long a resolved live version is reused before we ask the CDN again
versioncachettl = 300
versionlookuptimeout = 10
_robloxversioncache: Optional[str] = None
_robloxversioncacheat: float = 0.0
_reportedversion: Optional[str] = None


def allowstaleoffsets() -> bool:
    return os.environ.get(allowstaleenv, "").strip() in ("1", "true", "yes")


def robuildhash(version: Optional[str]) -> str:
    """Strip the 'version-' prefix so hashes compare consistently."""
    if not version:
        return ""
    return version[len("version-"):] if version.startswith("version-") else version


def isknownversion(version: Optional[str]) -> bool:
    """True when we recognise the version string at all."""
    return bool(version) and robuildhash(version) == defaultversionhash


def reportrobloxversion(version: Optional[str]) -> None:
    """Print the Roblox version once, however many times we resolve it."""
    global _reportedversion
    if version and version != _reportedversion:
        _reportedversion = version
        print(f"[ + ] Roblox version: {version}")


def getrobloxversion(timeout: int = versionlookuptimeout, usecache: bool = True) -> Optional[str]:
    """Ask roblox which client version is current, e.g. 'version-c5aecda2245e4fae'.

    The result is cached briefly; one run only ever needs to ask once.
    """
    global _robloxversioncache, _robloxversioncacheat

    if usecache and _robloxversioncache:
        age = time.monotonic() - _robloxversioncacheat
        if age < versioncachettl:
            return _robloxversioncache

    try:
        response = requests.get(robloxversionendpoint, timeout=timeout)
        if response.status_code != 200:
            print(
                f"[ - ] Roblox version endpoint returned HTTP {response.status_code}")
            return None
        upload = response.json().get("clientVersionUpload")
        if not upload:
            print("[ - ] Roblox version response missing clientVersionUpload")
            return None
        version = upload if upload.startswith(
            "version-") else f"version-{upload}"
        _robloxversioncache = version
        _robloxversioncacheat = time.monotonic()
        return version
    except Exception as e:
        print(f"[ - ] Roblox version lookup failed: {e}")
        return None


def fetchmagicoffset(version: str, timeout: int = 10) -> int:
    """Grab the FFlagList singleton pointer from theo's offsets for a specific version.

    Returns 0 on any failure. Never guesses.
    """
    try:
        response = requests.get(
            f"{offsetsbaseurl}/{version}/fflags.hpp", timeout=timeout)
        if response.status_code != 200:
            print(
                f"[ - ] theo returned HTTP {response.status_code} for {version}")
            return 0

        # Scope to the FFlagList namespace. DOTALL so the .*? can cross newlines;
        # non-greedy so we stop at the first Pointer inside the namespace.
        match = re.search(
            r"namespace\s+FFlagList\s*\{.*?Pointer\s*=\s*(0x[0-9a-fA-F]+)",
            response.text,
            re.DOTALL,
        )
        if not match:
            print(f"[ - ] FFlagList::Pointer not found in {version} dump")
            return 0

        offset = int(match.group(1), 16)
        if offset == 0:
            print(f"[ - ] FFlagList::Pointer parsed as 0 for {version}")
            return 0
        return offset
    except Exception as e:
        print(f"[ - ] offset fetch failed for {version}: {e}")
        return 0


def getthemagicoffset(version: Optional[str] = None) -> int:
    """Resolve the FFlagList offset.

    Priority:
      1. caller-supplied version
      2. live Roblox version from the CDN
      3. last-known-good hash -- last resort, auto-enabled but loudly warned
      4. hardcoded offset -- ONLY if ICY_ALLOW_STALE_OFFSETS=1

    Every path reports which Roblox build the offset belongs to.
    """
    clientversion = version or getrobloxversion()

    if clientversion:
        reportrobloxversion(clientversion)
        offset = fetchmagicoffset(clientversion)
        if offset:
            print(f"[ + ] FFlagList offset 0x{offset:X} ({clientversion})")
            return offset

        # dump missing/renamed: this is usually a brand new client build that
        # theo hasn't dumped yet, so the newest dump we do have is the best guess
        if isknownversion(clientversion):
            print(f"[ - ] theo has no dump for {clientversion}")
        else:
            print(f"[ - ] No offsets for {clientversion}, "
                  f"trying last known good dump")
            staleknown = f"version-{defaultversionhash}"
            offset = fetchmagicoffset(staleknown)
            if offset:
                print(f"[ ! ] WARNING: using offsets for {staleknown}, "
                      f"but client is {clientversion}. Values may be wrong.")
                print("[ ! ] This is a guess; if flags fail to apply, wait for a "
                      "fresh dump or set ICY_ALLOW_STALE_OFFSETS=0.")
                return offset
    else:
        print("[ - ] Could not detect live Roblox version")

    if allowstaleoffsets():
        print(f"[ ! ] WARNING: using built-in offset 0x{defaultmagicoffset:X} "
              f"for {defaultversionhash}. This is only valid for that exact build.")
        return defaultmagicoffset

    print(f"[ - ] No usable offset found. Set {allowstaleenv}=1 to force the "
          f"hardcoded fallback (0x{defaultmagicoffset:X}) at your own risk.")
    return 0


thebanner = r"""
██╗  ██████╗██╗   ██╗
██║ ██╔════╝╚██╗ ██╔╝
██║ ██║      ╚████╔╝
██║ ██║       ╚██╔╝
██║ ╚██████╗   ██║
╚═╝  ╚═════╝   ╚═╝
"""

mbasis = 0xcbf29ce484222325
mprime = 0x100000001b3
mbasisalt = 0x811c9dc5
mprimealt = 0x01000193

offfflagvalueptr = 0xc0
offmapend = 0x00
offmaplist = 0x10
offmapmask = 0x28
offentryforward = 0x08
offentrystring = 0x10
offentrygetset = 0x30
offstrbytes = 0x00
offstrsize = 0x10
offstralloc = 0x18
offstrcapacity = 0x18

nodereadsize = 64
nodestrides = [64, 72, 56, 80, 88, 96]
maxchainsteps = 128
maxchainsafety = 1000
minvalidptr = 0x10000
flagaddrlrumax = 4096


class therobbloxhacker:
    def __init__(self):
        self.memory = memoryman()
        self.mem = self.memory.mem
        self.processhandle: Optional[int] = None
        self.modulebase: int = 0
        self.modulesize: int = 0
        self.cachedsingleton = 0
        self.hashcache: Dict[str, int] = {}
        self.lookupmetacache: Dict[str, Dict[str, int]] = {}
        self.valueptrlru: OrderedDict[str, int] = OrderedDict()
        self.cachemapidentity: Tuple[int, int, int] = (0, 0, 0)
        self.theoffsetmagic: int = 0
        self.clientversion: Optional[str] = None
        self.clientbuildhash: str = "unknown"
        self.resolvingclientversion()
        self.attachingandfuckingroblox()
        self.theoffsetmagic = self.resolveoffset()
        if not self.theoffsetmagic:
            raise RuntimeError(
                "No valid FFlagList offset available; refusing to continue")

    def cachevalueptr(self, name: str, valueptr: int) -> None:
        if not valueptr:
            return
        self.valueptrlru[name] = valueptr
        self.valueptrlru.move_to_end(name)
        while len(self.valueptrlru) > flagaddrlrumax:
            self.valueptrlru.popitem(last=False)

    def getcachedvalueptr(self, name: str) -> int:
        valueptr = self.valueptrlru.get(name)
        if valueptr:
            self.valueptrlru.move_to_end(name)
            return valueptr
        return 0

    def isvalidptr(self, ptr: int) -> bool:
        return minvalidptr <= ptr <= 0x7FFFFFFFFFFF

    def fnv1a64(self, name: str) -> int:
        cached = self.hashcache.get(name)
        if cached is not None:
            return cached

        basis = mbasis
        prime = mprime
        for byte in name.encode("utf-8", errors="ignore"):
            basis ^= byte
            basis = (basis * prime) & 0xFFFFFFFFFFFFFFFF

        self.hashcache[name] = basis
        return basis

    def invalidatelookupcaches(self, clearhash: bool = False) -> None:
        self.lookupmetacache.clear()
        self.valueptrlru.clear()
        if clearhash:
            self.hashcache.clear()

    def readentrynamebytes(self, entrydata: bytes) -> Tuple[bytes, int]:
        if self.processhandle is None:
            return b"", 0

        strdatastart = offentrystring
        strsize = int.from_bytes(
            entrydata[strdatastart + offstrsize:strdatastart + offstrsize + 8],
            "little",
        )
        if strsize <= 0 or strsize > 256:
            return b"", 0

        stralloc = int.from_bytes(
            entrydata[strdatastart +
                      offstrcapacity:strdatastart + offstrcapacity + 8],
            "little",
        )

        if stralloc > 0xF:
            ptr = int.from_bytes(
                entrydata[strdatastart:strdatastart + 8], "little")
            if not self.isvalidptr(ptr):
                return b"", 0
            namebytes = self.mem.readmemory(self.processhandle, ptr, strsize)
            if not namebytes:
                return b"", 0
            return namebytes[:strsize], strsize

        return entrydata[strdatastart:strdatastart + strsize], strsize

    def readnodeentry(self, nodeptr: int) -> Optional[bytes]:
        if not self.isvalidptr(nodeptr) or self.processhandle is None:
            return None

        for readsize in nodestrides:
            if readsize < nodereadsize:
                continue
            entrydata = self.mem.readmemory(
                self.processhandle, nodeptr, readsize)
            if entrydata and len(entrydata) >= nodereadsize:
                return entrydata
        return None

    def resolvingclientversion(self) -> None:
        """Work out which Roblox build is running *before* we block on attach.

        The CDN tells us what is current right now, so the version gets reported
        even while the client isn't up yet. Once attached, the running client's
        install path overrides it because it can't go stale.
        """
        cdnversion = getrobloxversion()
        if cdnversion:
            self.clientversion = cdnversion
            self.clientbuildhash = robuildhash(cdnversion)
            reportrobloxversion(cdnversion)
        else:
            print("[ - ] Could not detect the live Roblox version")

    def attachingandfuckingroblox(self):
        print("[ + ] waiting for RobloxPlayerBeta.exe "
              "(launch Roblox if it isn't open) ")
        handle, base, size = self.memory.attachprocess(
            "RobloxPlayerBeta.exe",
            "RobloxPlayerBeta.exe",
        )
        if handle is None or base is None or size is None:
            raise RuntimeError("Failed to attach to Roblox process")
        self.processhandle = handle
        self.modulebase = base
        self.modulesize = size

        # the exe path is ...\Versions\version-<hash>\RobloxPlayerBeta.exe, which
        # names the build that is actually loaded (works even when the CDN lies)
        cdnversion = self.clientversion
        runningversion = None
        modulepath = self.memory.getmodulepath(
            "RobloxPlayerBeta.exe", "RobloxPlayerBeta.exe")
        if modulepath:
            print(f"[ + ] Module Path: {modulepath}")
            match = re.search(r"version-([0-9a-fA-F]{16,32})", modulepath)
            if match:
                runningversion = f"version-{match.group(1)}"

        # the running process wins over the CDN if they disagree
        if runningversion:
            if cdnversion and runningversion != cdnversion:
                print(f"[ ! ] WARNING: the CDN lists {cdnversion}, but the "
                      f"running client is {runningversion}. Using the running "
                      f"client's build.")
            self.clientversion = runningversion
            self.clientbuildhash = robuildhash(runningversion)

        if self.clientbuildhash == "unknown":
            print("[ - ] Roblox build: unknown")
        else:
            print(f"[ + ] Roblox build: {self.clientbuildhash} "
                  f"({self.clientversion})")
        print(f"[ + ] Attached to handle: 0x{self.processhandle:X}")
        print(f"[ + ] Module Base: 0x{self.modulebase:X}")
        print(f"[ + ] Module Size: 0x{self.modulesize:X}")

    def resolveoffset(self) -> int:
        """Resolve the offset, then validate it against the live process."""
        offset = getthemagicoffset(self.clientversion)
        if not offset:
            return 0

        print(f"[ + ] validating offset 0x{offset:X} against live process "
              f"({self.clientversion or 'unknown version'})...")
        if self.validateoffset(offset):
            print(f"[ + ] offset 0x{offset:X} validated "
                  f"for {self.clientbuildhash}")
            return offset

        print(f"[ - ] offset 0x{offset:X} did not validate; "
              f"the client build likely doesn't match the dump")

        # If we got here with an auto-detected version, the dump was wrong.
        # Try the last-known-good only if the user opted in.
        if allowstaleoffsets() and offset != defaultmagicoffset:
            print(f"[ - ] trying hardcoded fallback 0x{defaultmagicoffset:X}")
            if self.validateoffset(defaultmagicoffset):
                print(
                    f"[ + ] fallback offset 0x{defaultmagicoffset:X} validated")
                return defaultmagicoffset
            print(
                f"[ - ] fallback offset 0x{defaultmagicoffset:X} also failed")

        return 0

    def validateoffset(self, offset: int) -> bool:
        """Read the pointer at modulebase+offset and check it looks like FFlagList.

        We verify:
          - the pointer itself is a valid user-mode address
          - the hashmap header at +8 is readable and self-consistent
        """
        if self.processhandle is None:
            return False

        addr = self.modulebase + offset
        try:
            pointer = self.mem.readint64(self.processhandle, addr)
        except Exception:
            return False

        if not pointer or not self.isvalidptr(pointer):
            print(f"[ - ] pointer at modulebase+0x{offset:X} is 0x{pointer:X}")
            return False

        # hashmap header lives at pointer+8
        hashmapaddr = pointer + 8
        try:
            mapbytes = self.mem.readmemory(self.processhandle, hashmapaddr, 56)
        except Exception:
            return False

        if not mapbytes or len(mapbytes) < 56:
            print("[ - ] could not read FFlagList hashmap header")
            return False

        maplist = int.from_bytes(mapbytes[offmaplist:offmaplist + 8], 'little')
        mapmask = int.from_bytes(mapbytes[offmapmask:offmapmask + 8], 'little')

        if mapmask == 0:
            print("[ - ] hashmap mask is 0")
            return False
        if not self.isvalidptr(maplist):
            print(f"[ - ] hashmap list pointer 0x{maplist:X} is not valid")
            return False

        # cache what we learned so getsingleton() doesn't re-read
        self.cachedsingleton = pointer
        return True

    def getsingleton(self) -> int:
        if self.cachedsingleton:
            return self.cachedsingleton

        if self.processhandle is None:
            print("[ - ] No process handle available")
            return 0

        if not self.theoffsetmagic:
            print("[ - ] No FFlagList offset resolved")
            return 0

        print("[ + ] reading FFlagList offset")
        addr: int = self.modulebase + self.theoffsetmagic

        absolute = self.mem.readint64(self.processhandle, addr)

        if absolute and absolute > 0:
            self.cachedsingleton = absolute
            print(
                f"[ + ] Singleton (FFlagList) found at: 0x{absolute:X} "
                f"(from offset 0x{self.theoffsetmagic:X})")
            return absolute

        print("[ - ] Failed to read FFlagList rip .")
        return 0

    def _gethashmapinfo(self, singleton: int) -> Optional[Tuple[int, int, int]]:
        """Returns (mapend, maplist, mapmask) or None on failure."""
        if self.processhandle is None:
            return None
        hashmapaddr = singleton + 8
        mapbytes = self.mem.readmemory(self.processhandle, hashmapaddr, 56)
        if not mapbytes:
            return None

        mapend = int.from_bytes(mapbytes[offmapend:offmapend+8], 'little')
        maplist = int.from_bytes(mapbytes[offmaplist:offmaplist+8], 'little')
        mapmask = int.from_bytes(mapbytes[offmapmask:offmapmask+8], 'little')

        if mapmask == 0 or maplist == 0 or not self.isvalidptr(maplist):
            return None
        return mapend, maplist, mapmask

    def _checkcachednode(self, namebytes: bytes, meta: Dict[str, int]) -> int:
        """Check if cached node matches the flag name. Returns getset ptr or 0."""
        cachednode: int = meta.get("nodeptr", 0)
        if not cachednode or not self.isvalidptr(cachednode):
            return 0

        entrydata = self.readnodeentry(cachednode)
        if not entrydata:
            return 0

        entrynamebytes, entrylen = self.readentrynamebytes(entrydata)
        if entrylen != len(namebytes) or entrynamebytes != namebytes:
            return 0

        getset = int.from_bytes(
            entrydata[offentrygetset:offentrygetset+8], 'little')
        if not self.isvalidptr(getset):
            return 0
        return getset

    def _checknodematch(self, entrydata: bytes, namebytes: bytes) -> int:
        """Check if entrydata matches namebytes. Returns getset ptr or 0."""
        entrynamebytes, entrylen = self.readentrynamebytes(entrydata)
        if entrylen != len(namebytes) or entrynamebytes != namebytes:
            return 0
        getset = int.from_bytes(
            entrydata[offentrygetset:offentrygetset+8], 'little')
        if not self.isvalidptr(getset):
            return 0
        return getset

    def _searchhashchain(self, nodecurrent: int, name: str, namebytes: bytes,
                         bucketindex: int) -> int:
        """Search through hash chain for matching flag. Returns getset ptr or 0."""
        visited: set[int] = set()

        for _ in range(maxchainsafety):
            if nodecurrent in visited or len(visited) >= maxchainsteps:
                break
            visited.add(nodecurrent)

            entrydata = self.readnodeentry(nodecurrent)
            if not entrydata:
                return 0

            getset = self._checknodematch(entrydata, namebytes)
            if getset:
                self.lookupmetacache[name] = {
                    "bucketindex": bucketindex, "nodeptr": nodecurrent}
                self.cachevalueptr(name, getset)
                return getset

            forward = int.from_bytes(
                entrydata[offentryforward:offentryforward+8], 'little')
            if not forward or nodecurrent == forward or not self.isvalidptr(forward):
                return 0
            nodecurrent = forward

        return 0

    def whereistheflagat(self, name: str) -> int:
        if self.processhandle is None:
            return 0

        valueptr = self.getcachedvalueptr(name)
        if valueptr:
            return valueptr

        singleton = self.getsingleton()
        if not singleton:
            return 0

        namebytes = name.encode("utf-8")
        hashinfo = self._gethashmapinfo(singleton)
        if not hashinfo:
            return 0

        mapend, maplist, mapmask = hashinfo
        mapidentity = (maplist, mapend, mapmask)

        if mapidentity != self.cachemapidentity:
            self.invalidatelookupcaches(clearhash=False)
            self.cachemapidentity = mapidentity

        meta = self.lookupmetacache.get(name, {})
        if "bucketindex" in meta:
            bucketindex = meta["bucketindex"]
        else:
            basis = self.fnv1a64(name)
            bucketindex = basis & mapmask

        bucketindex &= mapmask
        bucketbase = maplist + (bucketindex * 16)

        bucketdata = self.mem.readmemory(self.processhandle, bucketbase, 16)
        if not bucketdata:
            return 0

        nodecurrent = int.from_bytes(bucketdata[8:16], 'little')
        if not self.isvalidptr(nodecurrent) or nodecurrent == mapend:
            return 0

        # Check cached node first
        getset = self._checkcachednode(namebytes, meta)
        if getset:
            return getset

        # Search through hash chain
        return self._searchhashchain(nodecurrent, name, namebytes, bucketindex)

    def changesthetext(self, name: str, value: str) -> bool:
        addr = self.whereistheflagat(name)
        if not addr or self.processhandle is None:
            return False

        try:
            return self.memory.writeflagstring(self.processhandle, addr, offfflagvalueptr, value)
        except Exception:
            return False

    def changesthenumber(self, name: str, value: int) -> bool:
        addr = self.whereistheflagat(name)
        if not addr or self.processhandle is None:
            return False

        try:
            return self.memory.writeflagint(self.processhandle, addr, offfflagvalueptr, value)
        except Exception:
            return False

    def themainfunctionlol(self, key: str) -> Tuple[str, str]:
        if key.startswith("FString"):
            return key[7:], "string"
        elif key.startswith("DFString"):
            return key[8:], "string"

        elif key.startswith("DFInt"):
            return key[5:], "int"
        elif key.startswith("FInt"):
            return key[4:], "int"
        elif key.startswith("DFLog"):
            return key[5:], "int"
        elif key.startswith("FLog"):
            return key[4:], "int"

        elif key.startswith("DFFlag"):
            return key[6:], "bool"
        elif key.startswith("FFlag"):
            return key[5:], "bool"

        else:
            if any(keyword in key.lower() for keyword in ['fahh']):
                return key, "bool"
            else:
                return key, "int"

    def _handlestringflag(self, key: str, cleanname: str, val: str | int | bool) -> Tuple[bool, str]:
        if self.changesthetext(cleanname, str(val)):
            return True, f"[ + ] {key} = \"{val}\""
        return False, f"[ - ] Failed: {key}"

    def _handleintflag(self, key: str, cleanname: str, val: str | int | bool) -> Tuple[bool, str]:
        try:
            targetvalue = int(val)
        except ValueError:
            return False, f"[ - ] Invalid int: {key}"

        if self.changesthenumber(cleanname, targetvalue):
            return True, f"[ + ] {key} = {targetvalue}"
        return False, f"[ - ] Failed: {key}"

    def _handleboolflag(self, key: str, cleanname: str, val: str | int | bool) -> Tuple[bool, str]:
        if isinstance(val, bool):
            targetvalue = 1 if val else 0
        else:
            targetvalue = 1 if str(val).lower() == "true" else 0

        if self.changesthenumber(cleanname, targetvalue):
            return True, f"[ + ] {key} = {bool(targetvalue)}"
        return False, f"[ - ] Failed: {key}"

    def doitnow(self, key: str, val: str | int | bool) -> Tuple[bool, str]:
        cleanname, flagtype = self.themainfunctionlol(key)

        try:
            if flagtype == "string":
                return self._handlestringflag(key, cleanname, val)
            elif flagtype == "int":
                return self._handleintflag(key, cleanname, val)
            elif flagtype == "bool":
                return self._handleboolflag(key, cleanname, val)
            else:
                return False, f"[ - ] Unknown type: {key}"
        except Exception as e:
            return False, f"[ - ] Error {key}: {str(e)}"

    def puttheflagsinthere(self, jsonpath: str):
        if not os.path.exists(jsonpath):
            print(f"[ - ] Error: File '{jsonpath}' not found!")
            return

        print(f"[ + ] Loading flags from: {jsonpath}")

        try:
            with open(jsonpath, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            print(f"[ - ] Error parsing JSON: {e}")
            return
        except Exception as e:
            print(f"[ - ] Error reading file: {e}")
            return

        totalflags = len(data)
        successful = 0

        for key, val in data.items():
            success, message = self.doitnow(key, val)
            print(message)

            if success:
                successful += 1

        print(f"Applied: {successful}/{totalflags}")

    def cleanup(self):
        self.invalidatelookupcaches(clearhash=True)
        if self.processhandle:
            closehandle(self.processhandle)


def getbasepath():
    if getattr(sys, 'frozen', False) or hasattr(sys, 'real_path'):
        return os.path.dirname(os.path.realpath(sys.executable))

    return os.path.dirname(os.path.abspath(__file__))


def setupconsoleencoding():
    """Make the console able to print the unicode banner.

    chcp alone is not enough: python binds sys.stdout's encoder at startup, so the
    code page has to change AND the stream has to be reconfigured for it to stick.
    """
    if sys.platform == 'win32':
        try:
            import subprocess
            subprocess.run('chcp 65001', shell=True, capture_output=True)
        except Exception:
            pass

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except Exception:
            pass


relaunchmarker = "ICY_FFLAG_IN_CONSOLE"
createnewconsole = 0x00000010


def needsitsownconsole() -> bool:
    """True when we weren't started from a real interactive console.

    An ide run button pipes stdout/stderr somewhere and gives us no tty, which
    breaks input() and hides the window, so those runs get their own cmd window.
    """
    if sys.platform != "win32":
        return False

    # once relaunched, stay put - otherwise we'd spawn windows forever
    if os.environ.get(relaunchmarker):
        return False

    # frozen builds already get their own console window from the exe subsystem
    if getattr(sys, "frozen", False):
        return False

    try:
        import ctypes
        hasconsole = bool(ctypes.windll.kernel32.GetConsoleWindow())
    except Exception:
        hasconsole = False

    try:
        interactive = sys.stdin is not None and sys.stdin.isatty()
    except Exception:
        interactive = False

    return not (hasconsole and interactive)


def buildconsolecmdline() -> Tuple[str, str, Dict[str, str]]:
    """Returns (cmdline, workdir, env) for the relaunched console."""
    scriptpath = os.path.abspath(__file__)
    workdir = os.path.dirname(scriptpath)
    comspec = os.environ.get("COMSPEC", "cmd.exe")

    if getattr(sys, "frozen", False):
        command = f'"{sys.executable}"'
    else:
        command = f'"{sys.executable}" "{scriptpath}"'

    env = dict(os.environ)
    env[relaunchmarker] = "1"

    # /k keeps the window open even if it dies before reaching input()
    return f'{comspec} /k "{command}"', workdir, env


def opencmdconsole() -> bool:
    """Pop a real cmd window running this script. True if one was opened."""
    if not needsitsownconsole():
        return False

    cmdline, workdir, env = buildconsolecmdline()
    try:
        import subprocess
        subprocess.Popen(
            cmdline,
            cwd=workdir,
            env=env,
            creationflags=createnewconsole,
        )
        return True
    except Exception as e:
        print(f"[ - ] Could not open console: {e}")
        return False


def main():
    setupconsoleencoding()

    # an ide run button pipes our output somewhere with no tty - relaunch in a real window
    if opencmdconsole():
        print("[ + ] Opened a new console window, closing this one...")
        return

    try:
        print(thebanner)
    except Exception:
        print("[ + ] Icy FFlag Injector \n")
    print("[ + ] Icy FFlag Injector - https://discord.gg/Y9TPgwvaQ5 \n")

    try:
        fflags = therobbloxhacker()

        exedir = getbasepath()
        jsonpath = os.path.join(exedir, "fflags.json")

        print(f"[ + ] Looking for fflags.json in: {jsonpath}")

        if not os.path.exists(jsonpath):
            print("[ - ] Error: fflags.json not found!")
            print(f"    Please place 'fflags.json' in: {exedir}")
        else:
            print("[ + ] Found fflags.json")
            fflags.puttheflagsinthere(jsonpath)

        fflags.cleanup()

    except Exception as e:
        print(f"\n[ - ] poop: {e}")

    print("\n[ + ] done now press enter to exit")
    input()


if __name__ == "__main__":
    main()
